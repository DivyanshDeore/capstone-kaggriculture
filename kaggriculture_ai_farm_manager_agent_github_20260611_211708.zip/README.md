# Kaggriculture AI Farm Manager Agent

Kaggriculture AI Farm Manager Agent is a lightweight Python and Streamlit project that simulates an autonomous AI farm manager. The agent controls a virtual farm for a 100-day season and attempts to maximize final profit under changing prices and weather.

## Features

- Farm starts with 1000 coins, 10 land plots, water supply, and seed inventory.
- Crops: Wheat, Corn, Tomato, and Rice.
- Each crop has seed cost, growth duration, water requirement, market value, yield, and risk profile.
- Dynamic daily market prices.
- Random weather events: Sunny, Rainy, Drought, and Storm.
- Weather affects water, crop growth, crop health, yield, and market prices.
- Autonomous decisions for planting, seed buying, harvesting, and selling.
- Strategy comparison:
  - Rule-based
  - Profit prediction
  - Risk-aware
- 100-day simulation with daily logs and decision logs.
- Analytics outputs:
  - Profit graph
  - Crop distribution graph
  - Resource usage graph
- Streamlit interface with:
  - Dashboard
  - Farm Status
  - Market Prices
  - Agent Decisions
  - Performance Analytics

## Project Structure

```text
kaggriculture_ai_farm_manager_agent/
  app.py
  agent.py
  farm.py
  market.py
  weather.py
  simulator.py
  requirements.txt
  README.md
  ARCHITECTURE.md
  example_results/
```

## Architecture Diagram

```mermaid
flowchart TD
    A["Streamlit UI<br/>app.py"] --> B["Simulation Engine<br/>simulator.py"]
    B --> C["Farm State<br/>farm.py"]
    B --> D["Dynamic Market<br/>market.py"]
    B --> E["Weather Generator<br/>weather.py"]
    B --> F["AI Agent<br/>agent.py"]
    F --> G["Rule-based Strategy"]
    F --> H["Profit Prediction Strategy"]
    F --> I["Risk-aware Strategy"]
    C --> J["Daily Logs"]
    D --> J
    E --> J
    F --> K["Decision Logs"]
    J --> L["Analytics CSV and Graphs"]
    K --> L
```

## Install

```bash
pip install -r requirements.txt
```

## Run the Simulation

```bash
python simulator.py
```

This writes CSV files and PNG charts to `example_results/`.

## Run the Streamlit App

```bash
streamlit run app.py
```

## Kaggle Notebook Usage

```python
!pip install -q -r requirements.txt
!python simulator.py
```

For the UI in Kaggle, run:

```python
!streamlit run app.py --server.port 8501 --server.headless true
```

## Example Simulation Results

The included example uses `seed=42` and a 100-day season. Generated files:

- `example_results/daily_logs.csv`
- `example_results/agent_decisions.csv`
- `example_results/strategy_summary.csv`
- `example_results/profit_graph.png`
- `example_results/crop_distribution_graph.png`
- `example_results/resource_usage_graph.png`

Summary from the included run:

| Strategy | Final coins | Final profit | Peak profit | Total revenue | Seed cost | Water used |
| --- | ---: | ---: | ---: | ---: | ---: | ---: |
| Rule-based | 15,654.84 | 14,654.84 | 14,701.84 | 15,980.84 | 1,326.00 | 2,084.72 |
| Risk-aware | 12,885.65 | 11,885.65 | 12,083.72 | 13,675.65 | 1,790.00 | 2,291.30 |
| Profit prediction | 12,248.83 | 11,248.83 | 12,075.60 | 13,289.83 | 2,041.00 | 2,302.20 |

Run `python simulator.py --seed 42 --days 100` to regenerate the same example.

## Design Notes

- The market is stochastic but mean-reverting, so prices move without exploding.
- Weather changes water availability, water demand, growth speed, crop health, storm damage, and price pressure.
- The profit prediction strategy scores crops by expected future crop value per growth day.
- The risk-aware strategy keeps a cash reserve and limits over-concentration in one crop.
- Final profit is measured from realized coins after final-day harvest and crop inventory liquidation.
