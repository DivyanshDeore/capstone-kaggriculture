"""Simulation runner and analytics export for Kaggriculture."""

from __future__ import annotations

import argparse
from dataclasses import dataclass
from pathlib import Path
from typing import Dict, List, Tuple

import matplotlib

matplotlib.use("Agg")

import matplotlib.pyplot as plt
import numpy as np
import pandas as pd

from agent import FarmAgent, STRATEGIES, StrategyBase
from farm import CROPS, Farm
from market import Market
from weather import WeatherGenerator


@dataclass
class SimulationResult:
    strategy: str
    daily_logs: pd.DataFrame
    decisions: pd.DataFrame
    summary: Dict[str, float]


class Simulator:
    def __init__(self, strategy: str | StrategyBase, days: int = 100, seed: int = 42) -> None:
        self.days = int(days)
        self.seed = int(seed)
        if isinstance(strategy, str):
            if strategy not in STRATEGIES:
                raise ValueError(f"Unknown strategy: {strategy}")
            self.strategy = STRATEGIES[strategy]()
        else:
            self.strategy = strategy

    def run(self) -> SimulationResult:
        farm = Farm()
        market = Market(seed=self.seed + 101)
        weather_generator = WeatherGenerator(seed=self.seed + 202)
        farm_rng = np.random.default_rng(self.seed + 303)
        agent = FarmAgent(self.strategy)

        daily_rows: List[Dict[str, object]] = []
        decision_rows: List[Dict[str, object]] = []

        total_water_used = 0.0
        total_destroyed = 0

        for day in range(1, self.days + 1):
            weather = weather_generator.next_weather(day)
            market.update(day, weather)

            day_decisions = agent.act(farm, market, weather, day, self.days)
            growth_metrics = farm.advance_day(weather, farm_rng)
            total_water_used += float(growth_metrics["water_used"])
            total_destroyed += int(growth_metrics["destroyed_plots"])

            if day == self.days:
                day_decisions.extend(self._final_liquidation(farm, market, day))

            decision_rows.extend(day_decisions)
            daily_rows.append(self._daily_row(farm, market, weather, day, growth_metrics, day_decisions))

        daily_logs = pd.DataFrame(daily_rows)
        decisions = pd.DataFrame(decision_rows)
        final_row = daily_logs.iloc[-1]
        total_revenue = decisions.loc[decisions["action"] == "sell", "coins_delta"].sum() if not decisions.empty else 0.0
        total_seed_cost = -decisions.loc[decisions["action"] == "buy_seeds", "coins_delta"].sum() if not decisions.empty else 0.0

        summary = {
            "strategy": self.strategy.name,
            "final_coins": round(float(final_row["coins"]), 2),
            "final_profit": round(float(final_row["realized_profit"]), 2),
            "peak_profit": round(float(daily_logs["profit"].max()), 2),
            "total_revenue": round(float(total_revenue), 2),
            "total_seed_cost": round(float(total_seed_cost), 2),
            "total_water_used": round(total_water_used, 2),
            "destroyed_plots": int(total_destroyed),
            "harvest_actions": int((decisions["action"] == "harvest").sum()) if not decisions.empty else 0,
        }

        return SimulationResult(self.strategy.name, daily_logs, decisions, summary)

    def _final_liquidation(self, farm: Farm, market: Market, day: int) -> List[Dict[str, object]]:
        decisions: List[Dict[str, object]] = []
        harvest_events = farm.harvest_ready(day)
        harvested_by_crop: Dict[str, int] = {}

        for event in harvest_events:
            crop = str(event["crop"])
            harvested_by_crop[crop] = harvested_by_crop.get(crop, 0) + int(event["quantity"])

        for crop, quantity in harvested_by_crop.items():
            decisions.append(
                {
                    "day": day,
                    "strategy": self.strategy.name,
                    "action": "harvest",
                    "crop": crop,
                    "quantity": quantity,
                    "coins_delta": 0.0,
                    "note": "Final-day harvest of ready crops",
                }
            )

        for sale in farm.liquidate_inventory(market.prices):
            if sale["quantity"] <= 0:
                continue
            crop = str(sale["crop"])
            decisions.append(
                {
                    "day": day,
                    "strategy": self.strategy.name,
                    "action": "sell",
                    "crop": crop,
                    "quantity": int(sale["quantity"]),
                    "coins_delta": sale["revenue"],
                    "note": f"Final liquidation at {market.prices[crop]:.2f} coins/unit",
                }
            )

        return decisions

    def _daily_row(
        self,
        farm: Farm,
        market: Market,
        weather,
        day: int,
        growth_metrics: Dict[str, float],
        decisions: List[Dict[str, object]],
    ) -> Dict[str, object]:
        planted = farm.planted_counts()
        farm_value = farm.farm_value(market.prices)

        row: Dict[str, object] = {
            "day": day,
            "strategy": self.strategy.name,
            "weather": weather.name,
            "coins": round(farm.coins, 2),
            "net_worth": farm_value,
            "profit": round(farm_value - farm.initial_coins, 2),
            "realized_profit": round(farm.coins - farm.initial_coins, 2),
            "water_supply": round(farm.water_supply, 2),
            "water_added": growth_metrics["water_added"],
            "water_used": growth_metrics["water_used"],
            "destroyed_plots": growth_metrics["destroyed_plots"],
            "empty_plots": farm.empty_plot_count(),
            "action_count": len(decisions),
            "actions": self._summarize_actions(decisions),
        }

        for crop in CROPS:
            key = crop.lower()
            row[f"planted_{key}"] = planted[crop]
            row[f"produce_{key}"] = farm.crop_inventory[crop]
            row[f"seeds_{key}"] = farm.seed_inventory[crop]
            row[f"price_{key}"] = market.prices[crop]

        return row

    @staticmethod
    def _summarize_actions(decisions: List[Dict[str, object]]) -> str:
        useful = [decision for decision in decisions if decision["action"] != "wait"]
        if not useful:
            return "wait"
        labels = []
        for decision in useful:
            labels.append(f"{decision['action']} {decision['quantity']} {decision['crop']}")
        return "; ".join(labels[:6])


def compare_strategies(days: int = 100, seed: int = 42) -> Tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame]:
    daily_frames: List[pd.DataFrame] = []
    decision_frames: List[pd.DataFrame] = []
    summaries: List[Dict[str, float]] = []

    for strategy_name in STRATEGIES:
        result = Simulator(strategy_name, days=days, seed=seed).run()
        daily_frames.append(result.daily_logs)
        decision_frames.append(result.decisions)
        summaries.append(result.summary)

    daily_logs = pd.concat(daily_frames, ignore_index=True)
    decisions = pd.concat(decision_frames, ignore_index=True)
    summary = pd.DataFrame(summaries).sort_values("final_profit", ascending=False).reset_index(drop=True)
    return daily_logs, decisions, summary


def save_analytics_graphs(daily_logs: pd.DataFrame, best_strategy: str, output_dir: Path) -> Dict[str, Path]:
    output_dir.mkdir(parents=True, exist_ok=True)
    paths: Dict[str, Path] = {}

    profit_pivot = daily_logs.pivot(index="day", columns="strategy", values="profit")
    fig, ax = plt.subplots(figsize=(10, 5))
    profit_pivot.plot(ax=ax, linewidth=2)
    ax.set_title("Profit Over 100 Farming Days")
    ax.set_xlabel("Day")
    ax.set_ylabel("Profit (coins)")
    ax.grid(True, alpha=0.25)
    ax.legend(title="Strategy")
    fig.tight_layout()
    paths["profit_graph"] = output_dir / "profit_graph.png"
    fig.savefig(paths["profit_graph"], dpi=150)
    plt.close(fig)

    selected = daily_logs[daily_logs["strategy"] == best_strategy].sort_values("day")
    crop_columns = [f"planted_{crop.lower()}" for crop in CROPS]
    fig, ax = plt.subplots(figsize=(10, 5))
    ax.stackplot(
        selected["day"],
        [selected[column] for column in crop_columns],
        labels=list(CROPS.keys()),
        alpha=0.88,
    )
    ax.set_title(f"Crop Distribution - {best_strategy}")
    ax.set_xlabel("Day")
    ax.set_ylabel("Planted plots")
    ax.set_ylim(0, 10)
    ax.grid(True, axis="y", alpha=0.25)
    ax.legend(loc="upper left")
    fig.tight_layout()
    paths["crop_distribution_graph"] = output_dir / "crop_distribution_graph.png"
    fig.savefig(paths["crop_distribution_graph"], dpi=150)
    plt.close(fig)

    fig, ax = plt.subplots(figsize=(10, 5))
    ax.plot(selected["day"], selected["water_supply"], label="Water supply", linewidth=2)
    ax.bar(selected["day"], selected["water_used"], label="Water used", alpha=0.35)
    ax.set_title(f"Resource Usage - {best_strategy}")
    ax.set_xlabel("Day")
    ax.set_ylabel("Water units")
    ax.grid(True, axis="y", alpha=0.25)
    ax.legend()
    fig.tight_layout()
    paths["resource_usage_graph"] = output_dir / "resource_usage_graph.png"
    fig.savefig(paths["resource_usage_graph"], dpi=150)
    plt.close(fig)

    return paths


def save_example_results(output_dir: str | Path | None = None, days: int = 100, seed: int = 42) -> Dict[str, Path]:
    project_dir = Path(__file__).resolve().parent
    result_dir = Path(output_dir) if output_dir is not None else project_dir / "example_results"
    result_dir.mkdir(parents=True, exist_ok=True)

    daily_logs, decisions, summary = compare_strategies(days=days, seed=seed)
    daily_path = result_dir / "daily_logs.csv"
    decisions_path = result_dir / "agent_decisions.csv"
    summary_path = result_dir / "strategy_summary.csv"

    daily_logs.to_csv(daily_path, index=False)
    decisions.to_csv(decisions_path, index=False)
    summary.to_csv(summary_path, index=False)

    best_strategy = str(summary.iloc[0]["strategy"])
    graph_paths = save_analytics_graphs(daily_logs, best_strategy, result_dir)

    return {
        "daily_logs": daily_path,
        "agent_decisions": decisions_path,
        "strategy_summary": summary_path,
        **graph_paths,
    }


def main() -> None:
    parser = argparse.ArgumentParser(description="Run the Kaggriculture farm manager simulation.")
    parser.add_argument("--days", type=int, default=100, help="Number of farming days to simulate.")
    parser.add_argument("--seed", type=int, default=42, help="Random seed for reproducible results.")
    parser.add_argument("--output", type=str, default=None, help="Directory for CSV and PNG outputs.")
    args = parser.parse_args()

    paths = save_example_results(output_dir=args.output, days=args.days, seed=args.seed)
    summary = pd.read_csv(paths["strategy_summary"])
    print("Kaggriculture AI Farm Manager Agent")
    print(summary.to_string(index=False))
    print("\nSaved outputs:")
    for label, path in paths.items():
        print(f"- {label}: {path}")


if __name__ == "__main__":
    main()
