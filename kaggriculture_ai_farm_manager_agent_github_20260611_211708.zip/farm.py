"""Core farm state and crop mechanics for Kaggriculture."""

from __future__ import annotations

from dataclasses import dataclass
from typing import Dict, Iterable, List, Optional


@dataclass(frozen=True)
class CropSpec:
    name: str
    seed_cost: float
    growth_duration: int
    water_requirement: float
    market_value: float
    yield_per_plot: int
    risk_factor: float


CROPS: Dict[str, CropSpec] = {
    "Wheat": CropSpec(
        name="Wheat",
        seed_cost=12.0,
        growth_duration=7,
        water_requirement=2.0,
        market_value=36.0,
        yield_per_plot=3,
        risk_factor=0.55,
    ),
    "Corn": CropSpec(
        name="Corn",
        seed_cost=18.0,
        growth_duration=10,
        water_requirement=3.0,
        market_value=52.0,
        yield_per_plot=4,
        risk_factor=0.75,
    ),
    "Tomato": CropSpec(
        name="Tomato",
        seed_cost=25.0,
        growth_duration=8,
        water_requirement=4.0,
        market_value=68.0,
        yield_per_plot=4,
        risk_factor=1.05,
    ),
    "Rice": CropSpec(
        name="Rice",
        seed_cost=22.0,
        growth_duration=12,
        water_requirement=5.0,
        market_value=62.0,
        yield_per_plot=5,
        risk_factor=0.95,
    ),
}


@dataclass
class LandPlot:
    plot_id: int
    crop: Optional[str] = None
    planted_day: Optional[int] = None
    growth: float = 0.0
    health: float = 1.0

    @property
    def is_empty(self) -> bool:
        return self.crop is None

    def reset(self) -> None:
        self.crop = None
        self.planted_day = None
        self.growth = 0.0
        self.health = 1.0


class Farm:
    """Mutable farm state used by agents and the simulator."""

    def __init__(
        self,
        coins: float = 1000.0,
        land_plots: int = 10,
        water_supply: float = 320.0,
        max_water: float = 600.0,
        seed_inventory: Optional[Dict[str, int]] = None,
    ) -> None:
        self.initial_coins = float(coins)
        self.coins = float(coins)
        self.land_plots = int(land_plots)
        self.water_supply = float(water_supply)
        self.max_water = float(max_water)
        self.seed_inventory = {crop: 0 for crop in CROPS}
        self.seed_inventory.update(seed_inventory or {"Wheat": 4, "Corn": 3, "Tomato": 2, "Rice": 2})
        self.crop_inventory = {crop: 0 for crop in CROPS}
        self.plots: List[LandPlot] = [LandPlot(plot_id=i + 1) for i in range(self.land_plots)]

    def empty_plots(self) -> List[LandPlot]:
        return [plot for plot in self.plots if plot.is_empty]

    def empty_plot_count(self) -> int:
        return len(self.empty_plots())

    def planted_counts(self) -> Dict[str, int]:
        counts = {crop: 0 for crop in CROPS}
        for plot in self.plots:
            if plot.crop:
                counts[plot.crop] += 1
        return counts

    def ready_counts(self) -> Dict[str, int]:
        counts = {crop: 0 for crop in CROPS}
        for plot in self.plots:
            if plot.crop and plot.growth >= CROPS[plot.crop].growth_duration:
                counts[plot.crop] += 1
        return counts

    def buy_seeds(self, crop: str, quantity: int) -> Dict[str, float]:
        if crop not in CROPS or quantity <= 0:
            return {"quantity": 0, "cost": 0.0}

        seed_cost = CROPS[crop].seed_cost
        affordable = int(self.coins // seed_cost)
        purchased = max(0, min(int(quantity), affordable))
        cost = purchased * seed_cost
        self.coins -= cost
        self.seed_inventory[crop] += purchased
        return {"quantity": purchased, "cost": round(cost, 2)}

    def plant(self, crop: str, quantity: int, day: int) -> int:
        if crop not in CROPS or quantity <= 0:
            return 0

        planted = 0
        for plot in self.empty_plots():
            if planted >= quantity or self.seed_inventory[crop] <= 0:
                break
            plot.crop = crop
            plot.planted_day = day
            plot.growth = 0.0
            plot.health = 1.0
            self.seed_inventory[crop] -= 1
            planted += 1
        return planted

    def harvest_ready(self, day: int) -> List[Dict[str, float]]:
        harvest_events: List[Dict[str, float]] = []
        for plot in self.plots:
            if not plot.crop:
                continue

            spec = CROPS[plot.crop]
            if plot.growth < spec.growth_duration:
                continue

            produce_units = max(1, int(round(spec.yield_per_plot * plot.health)))
            crop = plot.crop
            self.crop_inventory[crop] += produce_units
            harvest_events.append(
                {
                    "day": day,
                    "plot_id": plot.plot_id,
                    "crop": crop,
                    "quantity": produce_units,
                    "health": round(plot.health, 3),
                }
            )
            plot.reset()
        return harvest_events

    def sell_produce(self, crop: str, quantity: int, price: float) -> Dict[str, float]:
        if crop not in CROPS or quantity <= 0:
            return {"quantity": 0, "revenue": 0.0}

        sold = min(int(quantity), self.crop_inventory[crop])
        revenue = sold * float(price)
        self.crop_inventory[crop] -= sold
        self.coins += revenue
        return {"quantity": sold, "revenue": round(revenue, 2)}

    def receive_water(self, amount: float) -> float:
        before = self.water_supply
        self.water_supply = max(0.0, min(self.max_water, self.water_supply + float(amount)))
        return round(self.water_supply - before, 2)

    def advance_day(self, weather, rng) -> Dict[str, float]:
        water_added = self.receive_water(weather.water_delta)
        water_used = 0.0
        destroyed_plots = 0

        for plot in list(self.plots):
            if not plot.crop:
                continue

            spec = CROPS[plot.crop]
            required = spec.water_requirement * weather.water_demand_multiplier
            used = min(self.water_supply, required)
            self.water_supply -= used
            water_used += used

            water_ratio = 1.0 if required <= 0 else used / required
            growth_efficiency = 0.35 + (0.65 * water_ratio)
            plot.growth += weather.growth_modifier * growth_efficiency

            if water_ratio < 0.75:
                plot.health -= (0.75 - water_ratio) * 0.16 * spec.risk_factor
            else:
                plot.health += 0.008

            plot.health += weather.health_delta * spec.risk_factor

            damage_chance = weather.damage_chance * spec.risk_factor
            if damage_chance > 0 and rng.random() < damage_chance:
                plot.health -= 0.28 + (0.12 * spec.risk_factor)

            plot.health = max(0.0, min(1.2, plot.health))
            if plot.health <= 0.12:
                plot.reset()
                destroyed_plots += 1

        return {
            "water_added": round(water_added, 2),
            "water_used": round(water_used, 2),
            "destroyed_plots": destroyed_plots,
        }

    def farm_value(self, market_prices: Dict[str, float]) -> float:
        value = self.coins
        for crop, quantity in self.crop_inventory.items():
            value += quantity * market_prices[crop]
        for crop, quantity in self.seed_inventory.items():
            value += quantity * CROPS[crop].seed_cost * 0.5
        for plot in self.plots:
            if not plot.crop:
                continue
            spec = CROPS[plot.crop]
            progress = min(1.0, plot.growth / spec.growth_duration)
            value += spec.yield_per_plot * market_prices[plot.crop] * plot.health * progress * 0.65
        return round(value, 2)

    def inventory_rows(self, inventory: Dict[str, int]) -> List[Dict[str, int]]:
        return [{"crop": crop, "quantity": int(quantity)} for crop, quantity in inventory.items()]

    def plot_rows(self) -> List[Dict[str, object]]:
        rows: List[Dict[str, object]] = []
        for plot in self.plots:
            if not plot.crop:
                rows.append(
                    {
                        "plot_id": plot.plot_id,
                        "crop": "Empty",
                        "growth": 0.0,
                        "growth_target": 0,
                        "health": 0.0,
                        "planted_day": None,
                    }
                )
                continue

            spec = CROPS[plot.crop]
            rows.append(
                {
                    "plot_id": plot.plot_id,
                    "crop": plot.crop,
                    "growth": round(plot.growth, 2),
                    "growth_target": spec.growth_duration,
                    "health": round(plot.health, 3),
                    "planted_day": plot.planted_day,
                }
            )
        return rows

    def liquidate_inventory(self, prices: Dict[str, float]) -> List[Dict[str, float]]:
        events: List[Dict[str, float]] = []
        for crop in CROPS:
            if self.crop_inventory[crop] <= 0:
                continue
            sale = self.sell_produce(crop, self.crop_inventory[crop], prices[crop])
            events.append({"crop": crop, **sale})
        return events

    def total_inventory_units(self) -> int:
        return sum(self.crop_inventory.values())

    def planted_crop_names(self) -> Iterable[str]:
        for plot in self.plots:
            if plot.crop:
                yield plot.crop
