"""Dynamic crop market for the Kaggriculture simulation."""

from __future__ import annotations

from typing import Dict, List

import numpy as np

from farm import CROPS


class Market:
    """Mean-reverting market prices with weather-driven shocks."""

    def __init__(self, seed: int | None = None) -> None:
        self.rng = np.random.default_rng(seed)
        self.prices: Dict[str, float] = {crop: spec.market_value for crop, spec in CROPS.items()}
        self.history: List[Dict[str, float]] = []

    def update(self, day: int, weather) -> Dict[str, float]:
        updated: Dict[str, float] = {}
        for crop, spec in CROPS.items():
            current = self.prices[crop]
            base = spec.market_value
            mean_reversion = 0.06 * ((base - current) / base)
            random_shock = float(self.rng.normal(0, 0.055))
            weather_shock = weather.price_effects.get(crop, 0.0)
            new_price = current * (1 + mean_reversion + random_shock + weather_shock)
            new_price = float(np.clip(new_price, base * 0.55, base * 1.8))
            updated[crop] = round(new_price, 2)

        self.prices = updated
        self.history.append({"day": day, **updated})
        return self.prices

    def price_ratio(self, crop: str) -> float:
        return self.prices[crop] / CROPS[crop].market_value

    def trend(self, crop: str, window: int = 6) -> float:
        if len(self.history) < 2:
            return 0.0
        rows = self.history[-window:]
        if len(rows) < 2:
            return 0.0
        return (rows[-1][crop] - rows[0][crop]) / max(1, len(rows) - 1)

    def expected_price(self, crop: str, days_ahead: int) -> float:
        spec = CROPS[crop]
        trend_component = self.trend(crop) * min(days_ahead, 10)
        mean_reversion_target = (spec.market_value - self.prices[crop]) * 0.35
        expected = self.prices[crop] + trend_component + mean_reversion_target
        return round(float(np.clip(expected, spec.market_value * 0.55, spec.market_value * 1.8)), 2)

    def as_row(self) -> Dict[str, float]:
        return {f"price_{crop.lower()}": price for crop, price in self.prices.items()}
