"""Streamlit interface for Kaggriculture AI Farm Manager Agent."""

from __future__ import annotations

import matplotlib.pyplot as plt
import pandas as pd
import streamlit as st

from farm import CROPS
from simulator import compare_strategies


st.set_page_config(
    page_title="Kaggriculture AI Farm Manager Agent",
    layout="wide",
)


@st.cache_data(show_spinner=False)
def load_simulation(days: int, seed: int):
    return compare_strategies(days=days, seed=seed)


def crop_column(prefix: str, crop: str) -> str:
    return f"{prefix}_{crop.lower()}"


def page_dashboard(daily_logs: pd.DataFrame, summary: pd.DataFrame) -> None:
    st.title("Kaggriculture AI Farm Manager Agent")

    best = summary.iloc[0]
    cols = st.columns(4)
    cols[0].metric("Best strategy", str(best["strategy"]))
    cols[1].metric("Final profit", f"{best['final_profit']:,.0f} coins")
    cols[2].metric("Final coins", f"{best['final_coins']:,.0f}")
    cols[3].metric("Water used", f"{best['total_water_used']:,.0f}")

    profit_pivot = daily_logs.pivot(index="day", columns="strategy", values="profit")
    st.line_chart(profit_pivot, height=360)
    st.dataframe(summary, use_container_width=True, hide_index=True)


def page_farm_status(daily_logs: pd.DataFrame, selected_strategy: str) -> None:
    st.title("Farm Status")
    selected = daily_logs[daily_logs["strategy"] == selected_strategy].sort_values("day")
    latest = selected.iloc[-1]

    cols = st.columns(4)
    cols[0].metric("Coins", f"{latest['coins']:,.0f}")
    cols[1].metric("Net worth", f"{latest['net_worth']:,.0f}")
    cols[2].metric("Water supply", f"{latest['water_supply']:,.0f}")
    cols[3].metric("Empty plots", int(latest["empty_plots"]))

    planted_rows = [
        {"crop": crop, "planted plots": int(latest[crop_column("planted", crop)])}
        for crop in CROPS
    ]
    inventory_rows = [
        {
            "crop": crop,
            "produce units": int(latest[crop_column("produce", crop)]),
            "seed inventory": int(latest[crop_column("seeds", crop)]),
        }
        for crop in CROPS
    ]

    left, right = st.columns(2)
    with left:
        st.subheader("Land Allocation")
        st.bar_chart(pd.DataFrame(planted_rows).set_index("crop"), height=300)
    with right:
        st.subheader("Inventory")
        st.dataframe(pd.DataFrame(inventory_rows), use_container_width=True, hide_index=True)

    st.subheader("Daily Farm Value")
    st.line_chart(selected.set_index("day")[["net_worth", "realized_profit"]], height=280)


def page_market_prices(daily_logs: pd.DataFrame, selected_strategy: str) -> None:
    st.title("Market Prices")
    selected = daily_logs[daily_logs["strategy"] == selected_strategy].sort_values("day")
    price_columns = [crop_column("price", crop) for crop in CROPS]
    price_frame = selected.set_index("day")[price_columns]
    price_frame.columns = list(CROPS.keys())

    st.line_chart(price_frame, height=380)

    latest_prices = pd.DataFrame(
        [
            {
                "crop": crop,
                "latest price": selected.iloc[-1][crop_column("price", crop)],
                "base value": spec.market_value,
                "price ratio": round(selected.iloc[-1][crop_column("price", crop)] / spec.market_value, 2),
            }
            for crop, spec in CROPS.items()
        ]
    )
    st.dataframe(latest_prices, use_container_width=True, hide_index=True)


def page_agent_decisions(decisions: pd.DataFrame, selected_strategy: str) -> None:
    st.title("Agent Decisions")
    selected = decisions[decisions["strategy"] == selected_strategy].copy()

    cols = st.columns(3)
    cols[0].metric("Decision rows", len(selected))
    cols[1].metric("Harvests", int((selected["action"] == "harvest").sum()))
    cols[2].metric("Sales", int((selected["action"] == "sell").sum()))

    action_counts = selected["action"].value_counts().rename_axis("action").reset_index(name="count")
    st.bar_chart(action_counts.set_index("action"), height=280)
    st.dataframe(
        selected.sort_values(["day", "action"])[["day", "action", "crop", "quantity", "coins_delta", "note"]],
        use_container_width=True,
        hide_index=True,
        height=420,
    )


def page_performance_analytics(daily_logs: pd.DataFrame, selected_strategy: str) -> None:
    st.title("Performance Analytics")
    selected = daily_logs[daily_logs["strategy"] == selected_strategy].sort_values("day")

    st.subheader("Profit Comparison")
    profit_pivot = daily_logs.pivot(index="day", columns="strategy", values="profit")
    st.line_chart(profit_pivot, height=300)

    st.subheader("Crop Distribution")
    crop_columns = [crop_column("planted", crop) for crop in CROPS]
    crop_frame = selected.set_index("day")[crop_columns]
    crop_frame.columns = list(CROPS.keys())
    st.area_chart(crop_frame, height=300)

    st.subheader("Resource Usage")
    fig, ax = plt.subplots(figsize=(10, 4))
    ax.plot(selected["day"], selected["water_supply"], label="Water supply", linewidth=2)
    ax.bar(selected["day"], selected["water_used"], label="Water used", alpha=0.35)
    ax.set_xlabel("Day")
    ax.set_ylabel("Water units")
    ax.grid(True, axis="y", alpha=0.25)
    ax.legend()
    st.pyplot(fig, clear_figure=True)


def main() -> None:
    with st.sidebar:
        st.header("Simulation")
        days = st.slider("Season days", min_value=30, max_value=150, value=100, step=5)
        seed = st.number_input("Random seed", min_value=1, max_value=9999, value=42, step=1)
        page = st.radio(
            "Page",
            [
                "Dashboard",
                "Farm Status",
                "Market Prices",
                "Agent Decisions",
                "Performance Analytics",
            ],
        )

    daily_logs, decisions, summary = load_simulation(days=int(days), seed=int(seed))
    strategies = list(summary["strategy"])

    if page == "Dashboard":
        page_dashboard(daily_logs, summary)
        return

    with st.sidebar:
        selected_strategy = st.selectbox("Strategy", strategies)

    if page == "Farm Status":
        page_farm_status(daily_logs, selected_strategy)
    elif page == "Market Prices":
        page_market_prices(daily_logs, selected_strategy)
    elif page == "Agent Decisions":
        page_agent_decisions(decisions, selected_strategy)
    elif page == "Performance Analytics":
        page_performance_analytics(daily_logs, selected_strategy)


if __name__ == "__main__":
    main()
