"""Autonomous farm agents and strategy layer."""

from __future__ import annotations

from abc import ABC, abstractmethod
from math import ceil
from typing import Dict, List

from farm import CROPS, Farm


class StrategyBase(ABC):
    name = "Base"
    cash_reserve = 0.0
    max_crop_share = 1.0

    def sell_plan(self, farm: Farm, market, weather, day: int, days_remaining: int) -> Dict[str, int]:
        plan: Dict[str, int] = {}
        for crop, quantity in farm.crop_inventory.items():
            if quantity <= 0:
                continue
            if days_remaining <= 1 or self.should_sell(crop, farm, market, weather, days_remaining):
                plan[crop] = quantity
        return plan

    def should_sell(self, crop: str, farm: Farm, market, weather, days_remaining: int) -> bool:
        return market.price_ratio(crop) >= 1.08

    def planting_plan(self, farm: Farm, market, weather, day: int, days_remaining: int) -> Dict[str, int]:
        scores = self.crop_scores(farm, market, weather, day, days_remaining)
        return self._plan_from_scores(scores, farm, days_remaining)

    @abstractmethod
    def crop_scores(self, farm: Farm, market, weather, day: int, days_remaining: int) -> Dict[str, float]:
        raise NotImplementedError

    def _plan_from_scores(self, scores: Dict[str, float], farm: Farm, days_remaining: int) -> Dict[str, int]:
        empty = farm.empty_plot_count()
        if empty <= 0:
            return {}

        candidates = [
            (crop, score)
            for crop, score in scores.items()
            if score > 0 and CROPS[crop].growth_duration <= days_remaining
        ]
        candidates.sort(key=lambda item: item[1], reverse=True)

        if not candidates:
            if CROPS["Wheat"].growth_duration <= days_remaining:
                candidates = [("Wheat", 0.1)]
            else:
                return {}

        remaining = empty
        available_cash = max(0.0, farm.coins - self.cash_reserve)
        share_limit = max(1, ceil(empty * self.max_crop_share))
        plan = {crop: 0 for crop in CROPS}

        for crop, _score in candidates:
            if remaining <= 0:
                break
            spec = CROPS[crop]
            affordable_with_cash = farm.seed_inventory[crop] + int(available_cash // spec.seed_cost)
            quantity = min(remaining, affordable_with_cash, share_limit)
            if quantity <= 0:
                continue

            seed_need = max(0, quantity - farm.seed_inventory[crop])
            available_cash -= seed_need * spec.seed_cost
            plan[crop] += quantity
            remaining -= quantity

        return {crop: quantity for crop, quantity in plan.items() if quantity > 0}


class RuleBasedStrategy(StrategyBase):
    name = "Rule-based"

    def crop_scores(self, farm: Farm, market, weather, day: int, days_remaining: int) -> Dict[str, float]:
        scores: Dict[str, float] = {}
        low_water = farm.water_supply < 140
        for crop, spec in CROPS.items():
            if spec.growth_duration > days_remaining:
                scores[crop] = -1.0
                continue

            score = 0.75 + market.price_ratio(crop)
            score += (14 - spec.growth_duration) * 0.035

            if weather.name == "Rainy":
                score += {"Rice": 0.32, "Tomato": 0.12}.get(crop, 0.0)
            elif weather.name == "Drought":
                score += {"Wheat": 0.38, "Corn": 0.15, "Tomato": -0.18, "Rice": -0.28}.get(crop, 0.0)
            elif weather.name == "Storm":
                score += {"Wheat": 0.18, "Corn": 0.05, "Tomato": -0.12, "Rice": -0.08}.get(crop, 0.0)

            if low_water:
                score -= spec.water_requirement * 0.13

            scores[crop] = score
        return scores

    def should_sell(self, crop: str, farm: Farm, market, weather, days_remaining: int) -> bool:
        return market.price_ratio(crop) >= 1.08 or (farm.coins < 120 and market.price_ratio(crop) >= 0.96)


class ProfitPredictionStrategy(StrategyBase):
    name = "Profit prediction"

    def crop_scores(self, farm: Farm, market, weather, day: int, days_remaining: int) -> Dict[str, float]:
        scores: Dict[str, float] = {}
        for crop, spec in CROPS.items():
            if spec.growth_duration > days_remaining:
                scores[crop] = -1.0
                continue

            expected_price = market.expected_price(crop, spec.growth_duration)
            gross = expected_price * spec.yield_per_plot
            water_cost = spec.water_requirement * spec.growth_duration * 0.22
            net = gross - spec.seed_cost - water_cost
            adjusted_duration = max(1.0, spec.growth_duration / max(0.45, weather.growth_modifier))
            repeat_bonus = 1 + (days_remaining // max(1, spec.growth_duration)) * 0.025
            scores[crop] = (net / adjusted_duration) * repeat_bonus
        return scores

    def should_sell(self, crop: str, farm: Farm, market, weather, days_remaining: int) -> bool:
        near_term_expected = market.expected_price(crop, min(4, days_remaining))
        current = market.prices[crop]
        return current >= near_term_expected * 0.98 or market.price_ratio(crop) >= 1.18 or farm.coins < 80


class RiskAwareStrategy(StrategyBase):
    name = "Risk-aware"
    cash_reserve = 150.0
    max_crop_share = 0.5

    def crop_scores(self, farm: Farm, market, weather, day: int, days_remaining: int) -> Dict[str, float]:
        scores: Dict[str, float] = {}
        for crop, spec in CROPS.items():
            if spec.growth_duration > days_remaining:
                scores[crop] = -1.0
                continue

            expected_price = market.expected_price(crop, spec.growth_duration)
            gross = expected_price * spec.yield_per_plot
            water_cost = spec.water_requirement * spec.growth_duration * 0.28
            net = gross - spec.seed_cost - water_cost
            base_score = net / max(1, spec.growth_duration)

            drought_penalty = spec.water_requirement * 1.6 if weather.name == "Drought" else 0.0
            storm_penalty = spec.risk_factor * 3.0 if weather.name == "Storm" else 0.0
            concentration_penalty = farm.planted_counts()[crop] * 0.7
            risk_penalty = spec.risk_factor * 4.5 + spec.water_requirement * 0.55
            scores[crop] = base_score - risk_penalty - drought_penalty - storm_penalty - concentration_penalty
        return scores

    def should_sell(self, crop: str, farm: Farm, market, weather, days_remaining: int) -> bool:
        ratio = market.price_ratio(crop)
        bad_weather = weather.name in {"Drought", "Storm"}
        return ratio >= 1.03 or farm.coins < 250 or (bad_weather and ratio >= 0.95)


STRATEGIES = {
    "Rule-based": RuleBasedStrategy,
    "Profit prediction": ProfitPredictionStrategy,
    "Risk-aware": RiskAwareStrategy,
}


class FarmAgent:
    def __init__(self, strategy: StrategyBase) -> None:
        self.strategy = strategy

    def act(self, farm: Farm, market, weather, day: int, total_days: int) -> List[Dict[str, object]]:
        days_remaining = total_days - day + 1
        decisions: List[Dict[str, object]] = []

        harvest_events = farm.harvest_ready(day)
        harvested_by_crop: Dict[str, int] = {}
        harvested_plots: Dict[str, int] = {}
        for event in harvest_events:
            crop = str(event["crop"])
            harvested_by_crop[crop] = harvested_by_crop.get(crop, 0) + int(event["quantity"])
            harvested_plots[crop] = harvested_plots.get(crop, 0) + 1

        for crop, quantity in harvested_by_crop.items():
            decisions.append(
                {
                    "day": day,
                    "strategy": self.strategy.name,
                    "action": "harvest",
                    "crop": crop,
                    "quantity": quantity,
                    "coins_delta": 0.0,
                    "note": f"Harvested {harvested_plots[crop]} ready plot(s)",
                }
            )

        sell_plan = self.strategy.sell_plan(farm, market, weather, day, days_remaining)
        for crop, quantity in sell_plan.items():
            sale = farm.sell_produce(crop, quantity, market.prices[crop])
            if sale["quantity"] <= 0:
                continue
            decisions.append(
                {
                    "day": day,
                    "strategy": self.strategy.name,
                    "action": "sell",
                    "crop": crop,
                    "quantity": int(sale["quantity"]),
                    "coins_delta": sale["revenue"],
                    "note": f"Sold at {market.prices[crop]:.2f} coins/unit",
                }
            )

        plant_plan = self.strategy.planting_plan(farm, market, weather, day, days_remaining)
        for crop, quantity in plant_plan.items():
            seed_need = max(0, quantity - farm.seed_inventory[crop])
            if seed_need > 0:
                purchase = farm.buy_seeds(crop, seed_need)
                if purchase["quantity"] > 0:
                    decisions.append(
                        {
                            "day": day,
                            "strategy": self.strategy.name,
                            "action": "buy_seeds",
                            "crop": crop,
                            "quantity": int(purchase["quantity"]),
                            "coins_delta": -purchase["cost"],
                            "note": f"Bought seeds for planned planting",
                        }
                    )

            planted = farm.plant(crop, quantity, day)
            if planted > 0:
                decisions.append(
                    {
                        "day": day,
                        "strategy": self.strategy.name,
                        "action": "plant",
                        "crop": crop,
                        "quantity": planted,
                        "coins_delta": 0.0,
                        "note": f"Allocated {planted} land plot(s)",
                    }
                )

        if not decisions:
            decisions.append(
                {
                    "day": day,
                    "strategy": self.strategy.name,
                    "action": "wait",
                    "crop": "None",
                    "quantity": 0,
                    "coins_delta": 0.0,
                    "note": "No profitable or available action",
                }
            )

        return decisions
