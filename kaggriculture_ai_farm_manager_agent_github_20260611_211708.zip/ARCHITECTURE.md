# Kaggriculture AI Farm Manager Agent Architecture

```mermaid
flowchart TD
    A["Streamlit UI<br/>app.py"] --> B["Simulation Engine<br/>simulator.py"]
    B --> C["Farm State<br/>farm.py"]
    B --> D["Dynamic Market<br/>market.py"]
    B --> E["Weather Generator<br/>weather.py"]
    B --> F["AI Agent<br/>agent.py"]
    F --> G["Rule-based Strategy"]
    F --> H["Profit Prediction Strategy"]
    F --> I["Risk-aware Strategy"]
    C --> J["Daily Logs"]
    D --> J
    E --> J
    F --> K["Decision Logs"]
    J --> L["Analytics CSV and Graphs"]
    K --> L
```

## Data Flow

1. `weather.py` creates one weather event per simulated day.
2. `market.py` updates crop prices based on stochastic movement and weather shocks.
3. `agent.py` inspects farm state, prices, weather, and remaining season length.
4. `farm.py` applies planting, seed purchases, harvests, sales, growth, water use, and storm damage.
5. `simulator.py` stores daily logs, decision logs, summary tables, and analytics graphs.
6. `app.py` renders the same simulation outputs in Streamlit.

## Runtime Profile

- No external APIs.
- No LLM calls.
- Uses small in-memory pandas DataFrames.
- Designed for a free Kaggle Notebook CPU runtime with less than 2 GB RAM.
