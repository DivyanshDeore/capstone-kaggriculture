"""Weather generation for the Kaggriculture simulation."""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Dict

import numpy as np


@dataclass(frozen=True)
class WeatherEvent:
    name: str
    water_delta: float
    growth_modifier: float
    water_demand_multiplier: float
    health_delta: float
    damage_chance: float
    price_effects: Dict[str, float] = field(default_factory=dict)


WEATHER_EVENTS = {
    "Sunny": WeatherEvent(
        name="Sunny",
        water_delta=18.0,
        growth_modifier=1.0,
        water_demand_multiplier=1.0,
        health_delta=0.004,
        damage_chance=0.0,
        price_effects={},
    ),
    "Rainy": WeatherEvent(
        name="Rainy",
        water_delta=58.0,
        growth_modifier=1.12,
        water_demand_multiplier=0.68,
        health_delta=0.014,
        damage_chance=0.01,
        price_effects={"Rice": -0.025, "Tomato": -0.012},
    ),
    "Drought": WeatherEvent(
        name="Drought",
        water_delta=-28.0,
        growth_modifier=0.62,
        water_demand_multiplier=1.45,
        health_delta=-0.032,
        damage_chance=0.02,
        price_effects={"Wheat": 0.025, "Corn": 0.04, "Tomato": 0.055, "Rice": 0.065},
    ),
    "Storm": WeatherEvent(
        name="Storm",
        water_delta=32.0,
        growth_modifier=0.74,
        water_demand_multiplier=0.85,
        health_delta=-0.018,
        damage_chance=0.12,
        price_effects={"Wheat": 0.02, "Corn": 0.028, "Tomato": 0.035, "Rice": 0.025},
    ),
}


class WeatherGenerator:
    """Pseudo-random weather with a mild seasonal drought bump."""

    def __init__(self, seed: int | None = None) -> None:
        self.rng = np.random.default_rng(seed)

    def next_weather(self, day: int) -> WeatherEvent:
        labels = ["Sunny", "Rainy", "Drought", "Storm"]
        probabilities = np.array([0.50, 0.25, 0.15, 0.10], dtype=float)

        if 45 <= day <= 75:
            probabilities += np.array([-0.06, -0.04, 0.08, 0.02])
        if day > 85:
            probabilities += np.array([0.03, -0.02, 0.01, -0.02])

        probabilities = probabilities / probabilities.sum()
        label = self.rng.choice(labels, p=probabilities)
        return WEATHER_EVENTS[str(label)]
